"""
AFM Configuration — Africa Frontier Markets
Production-hardened settings. No COSY references.
"""

from functools import lru_cache
from typing import List, Literal
from decimal import Decimal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Security
    secret_key: str = Field(..., min_length=48)
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = Field(default=15, ge=5, le=60)
    refresh_token_expire_days: int = Field(default=7, ge=1, le=30)

    @field_validator("secret_key")
    @classmethod
    def validate_secret_length(cls, v: str) -> str:
        if len(v) < 48:
            raise ValueError(f"SECRET_KEY must be >=48 characters, got {len(v)}")
        return v

    # Database
    database_url: str = Field(..., pattern=r"^postgresql\+asyncpg://")
    db_pool_size: int = Field(default=20, ge=5, le=100)
    db_max_overflow: int = Field(default=30, ge=0, le=100)
    db_pool_timeout: int = Field(default=30, ge=5, le=120)

    # Redis
    redis_url: str = Field(..., pattern=r"^redis://")
    redis_pool_size: int = Field(default=50, ge=10, le=200)

    # Payment Providers
    kora_api_key: str | None = None
    kora_secret_key: str | None = None
    fincra_api_key: str | None = None
    fincra_secret_key: str | None = None
    flutterwave_public_key: str | None = None
    flutterwave_secret_key: str | None = None
    stripe_publishable_key: str | None = None
    stripe_secret_key: str | None = None

    # Alpaca Trading
    alpaca_api_key: str | None = None
    alpaca_secret_key: str | None = None
    alpaca_paper: bool = True

    # Webhook Secrets
    kora_webhook_secret: str | None = None
    fincra_webhook_secret: str | None = None

    # Environment
    environment: Literal["development", "staging", "production"] = "development"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    json_logs: bool = True

    # CORS
    allowed_origins: str = "http://localhost:3000"

    # AFM B2B Revenue Model: commission per transaction (bps)
    afm_commission_bps: int = Field(default=25, ge=0, le=500)  # 0.25% per txn
    afm_min_fee_usd: Decimal = Field(default=Decimal("0.50"))
    afm_max_fee_usd: Decimal = Field(default=Decimal("50.00"))

    # Trading Limits
    max_order_value_usd: Decimal = Field(default=Decimal("10000"), ge=Decimal("100"))
    max_user_exposure_usd: Decimal = Field(default=Decimal("50000"), ge=Decimal("1000"))
    max_platform_exposure_usd: Decimal = Field(default=Decimal("400000"), ge=Decimal("10000"))

    # FX Spread
    fx_spread_bps: int = Field(default=50, ge=0, le=500)

    def get_allowed_origins(self) -> List[str]:
        return [o.strip() for o in self.allowed_origins.split(",")]

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def is_development(self) -> bool:
        return self.environment == "development"

    @property
    def is_staging(self) -> bool:
        return self.environment == "staging"


@lru_cache
def get_settings() -> Settings:
    return Settings()
